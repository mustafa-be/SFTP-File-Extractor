///usr/hdp/2.5.0.0-1245/spark2/jars/
//Zabbix is open source monitoring toll. need to learn
//import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.countDistinct
import spark_config.sparkConf
import scala.collection.mutable

object spark_learning
{

  def main(args: Array[String]): Unit =
  {


    val sparkSession = SparkSession.builder().config(conf = sparkConf).enableHiveSupport().getOrCreate()
    import sparkSession.implicits._
    var df=sparkSession.read.format("jdbc").options(Map("url" ->"jdbc:sqlite:/root/new_etl_test/parser_db.db","dbtable" -> "tbl_roster")).load()

    /*
    Suppose date_col starts from 20, col 20 to len(cols)-2 need to be unpivoted
    for each date col, add "    'col_value_in_row',`date_col_in_df`,  "
    */
    var stack_part=""
    var no_of_dtcolumns=df.columns.length-1
    for (i<-df.columns.slice(20,no_of_dtcolumns)){stack_part=stack_part+"'"+i.substring(0,10)+"'"+",`"+i+"`,"}
    /* Results in

    'col_value1',`date_col_in_df1`,'col_value2',`date_col_in_df2`,...'col_valuek',`date_col_in_dfk`,

    */


    // Suppose col 0-20 contain other column
    // Create a comma seprated list of cols
    var select_part=""
    for(col<-df.columns.slice(0,20)){select_part=select_part+"`"+col+"`,"}
    /* Results in

    `col1`,`col2`,`col3`,......`col_20`

    */



    stack_part="stack(98,"+stack_part.slice(0,stack_part.length()-1)+") as (duty_date,duty_time)"
    /* Results in

    stack('col_value1',`date_col_in_df1`,...'col_valuek',`date_col_in_dfk`) as (Date,value)

    */


    var query="select "+select_part+stack_part+",status from df"
    /* Results in

     select `col1`,`col2`,....,
     stack('col_value1',`date_col_in_df1`,...'col_valuek',`date_col_in_dfk`) as (Date,value),
     status from df;

    */

    df.createOrReplaceTempView("df")
    df=sparkSession.sql(query)

    /*
     Using 1,
     create new cols emp_shift_start_time,emp_shift_end_time
     check if length duty_time is 9,
        if true split and write to index 0,1 to emp_shift_start_time,emp_shift_end_time
     else
        write duty_time at emp_shift_details
     */
    val max_date=sparkSession.sql("select max(duty_date) as d from etl.cso_roster").select("d").collect()(0)(0)
    df=df.filter($"duty_date">max_date)

    println("\nRecords Filtered",df.count())

    println("\n")
    df.withColumn("emp_shift_start_time",when(length($"duty_time")===9,substring($"duty_time",1,2)).otherwise(null))
      .withColumn("emp_shift_end_time",when(length($"duty_time")===9,substring($"duty_time",6,2)).otherwise(null))
      .withColumn("emp_shift_details",when(length($"duty_time")=!=9,$"duty_time").otherwise(null))
      .repartition(1).write.mode("append").insertInto("etl.cso_roster")


    /*
     -No.1
     df.withColumn("emp_shift_start_time",when(length($"duty_time")===9,split($"duty_time","-")(0)).otherwise(""))
     .withColumn("emp_shift_end_time",when(length($"duty_time")===9,split($"duty_time","-")(1)).otherwise(""))
     .withColumn("emp_shift_details",when(length($"duty_time")=!=9,$"duty_time").otherwise(""))

     -No.2
     df.withColumn("_tmp", split($"duty_time", "-"))
     .withColumn("emp_shift_start_time",when(size($"_tmp")===2,$"_tmp".getItem(0)).otherwise(""))
     .withColumn("emp_shift_end_time",when(size($"_tmp")===2,$"_tmp".getItem(1)).otherwise(""))
     .withColumn("emp_shift_details",when(size($"_tmp")===1,$"_tmp".getItem(0)).otherwise(""))
     .drop("_tmp")

     -No.3
     df.withColumn("emp_shift_start_time",when(length($"duty_time")===9,substring($"duty_time",1,2)).otherwise(""))
     .withColumn("emp_shift_end_time",when(length($"duty_time")===9,substring($"duty_time",6,2)).otherwise(""))
     .withColumn("emp_shift_details",when(length($"duty_time")=!=9,$"duty_time").otherwise(""))

     -select("id","name","duty_date","duty_time","emp_shift_start_time","emp_shift_end_time","emp_shift_details").show(100)
    */
  }
}

import org.apache.spark.SparkConf

import java.io.File

object spark_config {
  val warehouseLocation = new File("spark-warehouse").getAbsolutePath
  val sparkConf = new SparkConf().setAppName("ERP_Payments_Data")
    .setMaster("local")
    .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    .set("spark.storage.memoryFraction", "0.4")
    .set("spark.memory.fraction", "1")
    .set("spark.executor.heartbeatInterval", "20s")
    .set("spark.dynamicAllocation.enabled", "false")
    .set("spark.cleaner.ttl", "3600")
    .set("enable.auto.commit", "false")
    .set("spark.sql.broadcastTimeout", "36000")
    .set("spark.task.maxFailures", "100")
    .set("spark.kryoserializer.buffer.mb", "24")
    .set("hive.exec.dynamic.partition.mode", "nonstrict")
    .set("spark.sql.warehouse.dir", warehouseLocation)


}
